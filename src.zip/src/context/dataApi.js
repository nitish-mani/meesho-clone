import { createContext } from "react";
const dataApi=createContext([]);
export default dataApi;
