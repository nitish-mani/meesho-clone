export default function Download() {
  return (
    <>
      <h1>App Downloaded Succeesfully</h1>
    </>
  );
}
