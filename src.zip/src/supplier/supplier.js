export default function Supplier() {
  return (
    <>
      <h1>Thank you for joining hand with us....</h1>
    </>
  );
}
